# CS336 Spring 2025 Assignment 1: Basics

This folder contains an optimized implementation of the model from assignment 1.
We strongly suggest that when testing out the usefulness of your filtered pretraining data, 
you use this implementation, since this is what we will use to evaluate leaderboard submissions.

Note that this is not a complete implementation of assignment 1, just a minimal implementation
of the trainer that is needed for assignment 4.